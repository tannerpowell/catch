import { defineField, defineType } from "sanity";
export default defineType({
  name: "menuItem",
  title: "Menu Item",
  type: "document",
  fields: [
    defineField({ name: "name", type: "string" }),
    defineField({ name: "slug", type: "slug", options: { source: "name" } }),
    defineField({ name: "category", type: "reference", to: [{ type: "menuCategory" }] }),
    defineField({ name: "description", type: "text" }),
    defineField({ name: "basePrice", type: "number" }),
    defineField({ name: "badges", type: "array", of: [{ type: "string" }] }),
    defineField({ name: "image", type: "image" }),
    defineField({
      name: "locationOverrides",
      title: "Per‑location Overrides",
      type: "array",
      of: [{
        type: "object",
        fields: [
          { name: "location", type: "reference", to: [{ type: "location" }] },
          { name: "price", type: "number" },
          { name: "available", type: "boolean" }
        ]
      }]
    })
  ]
});
