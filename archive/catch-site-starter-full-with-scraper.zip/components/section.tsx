import { ReactNode } from "react";
import { clsx } from "clsx";

export default function Section({ title, children, className }: { title?: string; children: ReactNode; className?: string }) {
  return (
    <section className={clsx("py-12", className)}>
      <div className="container">
        {title && <h2 className="mb-6 text-3xl font-display font-semibold">{title}</h2>}
        {children}
      </div>
    </section>
  );
}
