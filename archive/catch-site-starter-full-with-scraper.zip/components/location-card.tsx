import Link from "next/link";
import type { Location } from "@/lib/types";

export default function LocationCard({ loc }: { loc: Location }) {
  return (
    <div className="rounded-xl border p-4 shadow-sm">
      <h4 className="text-lg font-semibold">{loc.name}</h4>
      <p className="text-sm text-gray-600">{loc.addressLine1}, {loc.city}, {loc.state} {loc.postalCode}</p>
      {loc.phone && <p className="mt-1 text-sm"><a className="underline" href={`tel:${loc.phone}`}>{loc.phone}</a></p>}
      <div className="mt-3 flex gap-3 text-sm">
        <Link className="rounded-md border px-3 py-2" href={`/locations/${loc.slug}`}>Details</Link>
        {loc.menuUrl && <a className="rounded-md border px-3 py-2" href={loc.menuUrl}>View Menu</a>}
      </div>
    </div>
  );
}
