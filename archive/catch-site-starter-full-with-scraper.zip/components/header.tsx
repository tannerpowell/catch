import Link from "next/link";

const nav = [
  { href: "/menu", label: "Menu" },
  { href: "/locations", label: "Locations" },
  { href: "#", label: "Gift Cards" },
  { href: "#", label: "Our Story" }
];

export default function Header() {
  return (
    <header className="border-b border-border bg-paper/70 backdrop-blur">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="text-lg font-display font-bold tracking-wide">The Catch</Link>
        <nav className="flex gap-6 text-sm font-medium">
          {nav.map(i => (
            <Link key={i.href} href={i.href} className="hover:text-accent transition-colors">
              {i.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
