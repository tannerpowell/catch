import MenuCategoryBlock from "@/components/menu-category";
import Section from "@/components/section";
import { getBrand } from "@/lib/brand";
import { MenuJsonLd } from "@/components/jsonld";

export default async function MenuPage() {
  const brand = getBrand();
  const [categories, items] = await Promise.all([brand.getCategories(), brand.getItems()]);
  return (
    <>
      <MenuJsonLd categories={categories} items={items} />
      <Section title={`${brand.brandName} — Menu`}>
        <div className="space-y-12">
          {categories.map(cat => (
            <MenuCategoryBlock key={cat.slug} category={cat} items={items.filter(i => i.categorySlug === cat.slug)} />
          ))}
        </div>
      </Section>
    </>
  );
}
