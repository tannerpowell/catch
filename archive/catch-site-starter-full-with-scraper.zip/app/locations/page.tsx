import Section from "@/components/section";
import LocationCard from "@/components/location-card";
import { getBrand } from "@/lib/brand";

export default async function LocationsIndex() {
  const brand = getBrand();
  const locations = await brand.getLocations();
  return (
    <Section title="Locations">
      <div className="grid gap-4 md:grid-cols-2">
        {locations.map(l => <LocationCard key={l.slug} loc={l} />)}
      </div>
    </Section>
  );
}
