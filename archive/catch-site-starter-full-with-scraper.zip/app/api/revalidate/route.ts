import { NextResponse } from "next/server";

export async function POST() {
  // In production, verify secret and call revalidateTag()/revalidatePath() if using ISR.
  return NextResponse.json({ ok: true });
}
