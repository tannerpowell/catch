import Section from "@/components/section";
import { getBrand } from "@/lib/brand";

export default async function HomePage() {
  const brand = getBrand();
  const [categories, locations] = await Promise.all([brand.getCategories(), brand.getLocations()]);
  return (
    <>
      <Section title={`Welcome to ${brand.brandName}`}>
        <p className="max-w-2xl text-gray-700">
          Portable Next.js starter. Managers can edit menu, categories, and locations via the embedded Studio.
        </p>
      </Section>

      <Section title="Explore Menu">
        <ul className="flex flex-wrap gap-3">
          {categories.map(c => (
            <li key={c.slug} className="rounded-md border px-3 py-2 text-sm">{c.title}</li>
          ))}
        </ul>
      </Section>

      <Section title="Locations">
        <div className="grid gap-4 md:grid-cols-2">
          {locations.map(l => (
            <div key={l.slug} className="rounded-xl border p-4">
              <div className="flex items-baseline justify-between">
                <h3 className="text-lg font-semibold">{l.name}</h3>
                {l.openToday != null && <span className="text-xs opacity-70">{l.openToday ? "Open today" : "Closed"}</span>}
              </div>
              <p className="text-sm text-gray-600">{l.addressLine1}, {l.city}</p>
            </div>
          ))}
        </div>
      </Section>
    </>
  );
}
