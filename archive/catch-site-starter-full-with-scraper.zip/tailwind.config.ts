import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        ink: "#0E0E10",
        paper: "#FFFFFF",
        accent: "#B45309",
        accentMuted: "#FDE68A",
        subtle: "#6B7280",
        border: "#E5E7EB"
      },
      fontFamily: {
        display: ["var(--font-display)", "serif"],
        body: ["var(--font-body)", "sans-serif"]
      },
      borderRadius: { xl: "1.25rem" },
      boxShadow: { card: "0 8px 24px rgba(16,24,40,.08)" }
    }
  },
  plugins: []
} satisfies Config;
