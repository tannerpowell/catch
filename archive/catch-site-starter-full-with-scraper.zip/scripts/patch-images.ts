// scripts/patch-images.ts
// Patch Sanity documents by slug → image URL (external).
// Usage:
// 1) Prepare a mapping file `image-map.json` like:
//    { "captains-combo": "https://example.com/captain.jpg", ... }
// 2) Run: ts-node scripts/patch-images.ts image-map.json
import fs from "node:fs";
import path from "node:path";
import { createClient } from "@sanity/client";

const [,, mapFile] = process.argv;
if (!mapFile) {
  console.error("Usage: ts-node scripts/patch-images.ts image-map.json");
  process.exit(1);
}

const mapping = JSON.parse(fs.readFileSync(path.resolve(mapFile), "utf8"));

const client = createClient({
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID!,
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET!,
  apiVersion: "2025-10-01",
  token: process.env.SANITY_WRITE_TOKEN, // create a token in Sanity project settings
  useCdn: false
});

async function run() {
  for (const [slug, url] of Object.entries(mapping as Record<string,string>)) {
    // find item doc by slug
    const doc = await client.fetch('*[_type=="menuItem" && slug.current==$s][0]{_id}', { s: slug });
    if (!doc?._id) {
      console.warn("No menuItem found for slug:", slug);
      continue;
    }
    await client
      .patch(doc._id)
      .set({ image: { _type: "image", asset: { _type: "reference", _ref: url.startsWith("image-") ? url : undefined }, /* external url fallback: store in a plain field */ externalUrl: url } as any })
      .commit()
      .catch((e:any) => console.error("Patch failed", slug, e.message));
    console.log("Patched", slug);
  }
}
run().catch(e => { console.error(e); process.exit(1); });
