import type { Config } from "tailwindcss";

export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}", "./lib/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        brand: { primary: "#111827", accent: "#B45309" }
      },
      borderRadius: { xl: "1.25rem" }
    }
  },
  plugins: []
} satisfies Config;
