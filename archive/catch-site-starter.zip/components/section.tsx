import { ReactNode } from "react";
import { clsx } from "clsx";

export default function Section({ title, children, className }: { title?: string; children: ReactNode; className?: string }) {
  return (
    <section className={clsx("py-10", className)}>
      <div className="container">
        {title && <h2 className="mb-6 text-2xl font-semibold">{title}</h2>}
        {children}
      </div>
    </section>
  );
}
