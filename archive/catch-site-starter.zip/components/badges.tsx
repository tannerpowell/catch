import type { Badge } from "@/lib/types";

export function BadgePill({ label }: { label: Badge | string }) {
  return <span className="rounded-full border px-2 py-1 text-xs">{label}</span>;
}

export function BadgeList({ badges }: { badges?: (Badge | string)[] }) {
  if (!badges?.length) return null;
  return (
    <div className="mt-2 flex flex-wrap gap-2">
      {badges.map((b, i) => <BadgePill key={i} label={b} />)}
    </div>
  );
}
