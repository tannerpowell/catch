import Image from "next/image";
import { BadgeList } from "./badges";
import type { MenuItem } from "@/lib/types";

export default function MenuItemCard({ item }: { item: MenuItem }) {
  return (
    <div className="rounded-xl border p-4 shadow-sm">
      <div className="flex items-start gap-4">
        <div className="relative h-20 w-20 shrink-0 overflow-hidden rounded-lg bg-gray-100">
          <Image src={item.image || "/placeholder.jpg"} alt={item.name} fill className="object-cover" />
        </div>
        <div className="min-w-0">
          <div className="flex items-baseline justify-between gap-4">
            <h4 className="truncate text-lg font-semibold">{item.name}</h4>
            {item.price != null && <span className="text-brand-accent font-semibold">${item.price.toFixed(2)}</span>}
          </div>
          {item.description && <p className="mt-1 text-sm text-gray-600">{item.description}</p>}
          <BadgeList badges={item.badges} />
        </div>
      </div>
    </div>
  );
}
