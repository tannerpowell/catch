import Link from "next/link";

const nav = [
  { href: "/menu", label: "Menu" },
  { href: "/locations", label: "Locations" },
  { href: "#", label: "Gift Cards" },
  { href: "#", label: "Our Story" }
];

export default function Header() {
  return (
    <header className="border-b">
      <div className="container flex h-16 items-center justify-between">
        <Link href="/" className="text-lg font-bold">The Catch</Link>
        <nav className="flex gap-6 text-sm">
          {nav.map(i => (
            <Link key={i.href} href={i.href} className="hover:text-brand-accent">
              {i.label}
            </Link>
          ))}
        </nav>
      </div>
    </header>
  );
}
