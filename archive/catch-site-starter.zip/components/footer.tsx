export default function Footer() {
  return (
    <footer className="border-t">
      <div className="container flex h-20 items-center justify-between text-sm">
        <p>© {new Date().getFullYear()} The Catch</p>
        <div className="opacity-70">Built with Next.js + Tailwind + Sanity</div>
      </div>
    </footer>
  );
}
