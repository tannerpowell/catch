import type { MenuCategory, MenuItem } from "@/lib/types";
import MenuItemCard from "./menu-item-card";

export default function MenuCategoryBlock({ category, items }: { category: MenuCategory; items: MenuItem[] }) {
  return (
    <div className="space-y-4">
      <h3 className="text-xl font-semibold" id={category.slug}>{category.title}</h3>
      <div className="grid gap-4 md:grid-cols-2">
        {items.map(i => <MenuItemCard key={i.id} item={i} />)}
      </div>
    </div>
  );
}
