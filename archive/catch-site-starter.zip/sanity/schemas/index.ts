import location from "./location";
import menuCategory from "./menuCategory";
import menuItem from "./menuItem";

export const schemaTypes = [location, menuCategory, menuItem];
