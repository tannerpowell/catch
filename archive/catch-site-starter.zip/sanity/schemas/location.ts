import { defineField, defineType } from "sanity";
export default defineType({
  name: "location",
  title: "Location",
  type: "document",
  fields: [
    defineField({ name: "name", type: "string" }),
    defineField({ name: "slug", type: "slug", options: { source: "name" } }),
    defineField({ name: "addressLine1", type: "string" }),
    defineField({ name: "addressLine2", type: "string" }),
    defineField({ name: "city", type: "string" }),
    defineField({ name: "state", type: "string" }),
    defineField({ name: "postalCode", type: "string" }),
    defineField({ name: "phone", type: "string" }),
    defineField({
      name: "hours",
      type: "object",
      fields: [
        { name: "sunday", type: "string" }, { name: "monday", type: "string" },
        { name: "tuesday", type: "string" }, { name: "wednesday", type: "string" },
        { name: "thursday", type: "string" }, { name: "friday", type: "string" },
        { name: "saturday", type: "string" }
      ]
    }),
    defineField({ name: "menuUrl", type: "url" }),
    defineField({ name: "directionsUrl", type: "url" })
  ]
});
