# The Catch — Next.js + Sanity Starter

## What you get
- Next.js (app dir) + Tailwind
- Sanity embedded Studio at `/studio`
- Zod-validated adapter that normalizes data for pages/components
- Per-location menu pricing/availability

## 1) Setup Sanity (once)
1. Create a Sanity project at https://www.sanity.io/manage (or `npm i -g sanity && sanity init`).
2. Note your **projectId** and **dataset** (e.g., `production`).

## 2) Configure env
Create `.env.local` in the repo root:
```
BRAND=cms-catch
NEXT_PUBLIC_SANITY_PROJECT_ID=yourProjectId
NEXT_PUBLIC_SANITY_DATASET=production
NEXT_PUBLIC_SITE_URL=http://localhost:3000
REVALIDATE_SECRET=devsecret
```

## 3) Install & run
```bash
npm install
npm run dev
# visit http://localhost:3000 (site) and http://localhost:3000/studio (CMS)
```

## 4) Create base content in Studio
- **Locations**: add the 4 starting locations (name, slug, address, phone, hours).
- **Menu Categories**: add in the order you want (e.g., Popular, Starters, Baskets, Combos, ...). Set `position` integers.
- **Menu Items**: assign a category and set `basePrice`. For per-location changes, add rows in **Per-location Overrides** (pick a location, set `price` and/or `available`).

## 5) See it live
- `/menu` renders categories + items.
- `/locations` lists locations; `/locations/[slug]` shows detail.
- Data will update instantly in dev. For prod, use Sanity webhooks → `/api/revalidate?secret=REVALIDATE_SECRET` to re-build/ISR.

## Optional: Deploy
- Vercel works out-of-the-box. Add env vars in the project settings.
- Point a Sanity webhook to your deploy’s `/api/revalidate?secret=...`.

## Notes
- Keep using the **adapter** as the only place you shape data coming from Sanity.
- You can later add JSON-LD, search/filters, and design tokens without changing the adapter API.
