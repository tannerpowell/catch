import { createClient } from "@sanity/client";
import groq from "groq";
import type { BrandAdapter, Location, MenuCategory, MenuItem } from "@/lib/types";
import { z } from "zod";

const client = createClient({
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID!,
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET!,
  apiVersion: "2025-10-01",
  useCdn: true
});

const HoursSchema = z.object({
  sunday: z.string().optional(), monday: z.string().optional(), tuesday: z.string().optional(),
  wednesday: z.string().optional(), thursday: z.string().optional(), friday: z.string().optional(), saturday: z.string().optional()
}).optional();

const LocationSchema = z.object({
  name: z.string(), slug: z.string(), addressLine1: z.string(), addressLine2: z.string().optional(),
  city: z.string(), state: z.string(), postalCode: z.string(), phone: z.string().optional(),
  hours: HoursSchema, menuUrl: z.string().url().optional(), directionsUrl: z.string().url().optional()
});

const CategorySchema = z.object({
  slug: z.string(), title: z.string(), position: z.number().optional(), description: z.string().optional()
});

const ItemSchema = z.object({
  id: z.string(), name: z.string(), slug: z.string(), categorySlug: z.string(),
  description: z.string().optional(), price: z.number().nullable().optional(),
  badges: z.array(z.string()).optional(), image: z.string().optional(),
  locationOverrides: z.record(z.string(), z.object({ price: z.number().optional(), available: z.boolean().optional() })).optional()
});

const qCategories = groq`*[_type=="menuCategory"]|order(position asc){ "slug": slug.current, title, position, description }`;
const qLocations  = groq`*[_type=="location"]{ name, "slug": slug.current, addressLine1, addressLine2, city, state, postalCode, phone, hours, menuUrl, directionsUrl }`;
const qItems = groq`*[_type=="menuItem"]{ _id, name, "slug": slug.current, description, "categorySlug": category->slug.current, "image": image.asset->url, badges, "basePrice": coalesce(basePrice, null), "overrides": coalesce(locationOverrides, [])[]{ "loc": location->slug.current, price, available } }`;

function normalizeOverrides(arr: { loc: string; price?: number; available?: boolean }[] | undefined) {
  const out: Record<string, { price?: number; available?: boolean }> = {};
  (arr||[]).forEach(o => { out[o.loc] = { price: o.price, available: o.available }; });
  return out;
}

export const adapter: BrandAdapter = {
  brandName: "The Catch Houston (CMS)",
  async getCategories(): Promise<MenuCategory[]> {
    const raw = await client.fetch(qCategories);
    return z.array(CategorySchema).parse(raw);
  },
  async getLocations(): Promise<Location[]> {
    const raw = await client.fetch(qLocations);
    const parsed = z.array(LocationSchema).parse(raw);
    return parsed.map((l) => ({ ...l, openToday: !!l.hours }));
  },
  async getItems(): Promise<MenuItem[]> {
    const raw = await client.fetch(qItems);
    const mapped = raw.map((i: any) => ({
      id: i._id, name: i.name, slug: i.slug, categorySlug: i.categorySlug,
      description: i.description, price: i.basePrice ?? null, badges: i.badges, image: i.image,
      locationOverrides: normalizeOverrides(i.overrides)
    }));
    return z.array(ItemSchema).parse(mapped);
  },
  async getLocationBySlug(slug: string) {
    const one = await client.fetch(groq`*[_type=="location" && slug.current==$s][0]{ name, "slug": slug.current, addressLine1, addressLine2, city, state, postalCode, phone, hours, menuUrl, directionsUrl }`, { s: slug });
    return one ? LocationSchema.parse(one) : undefined;
  },
  async getItemsByCategory(slug: string) {
    const all = await this.getItems();
    return all.filter(i => i.categorySlug === slug);
  }
};
