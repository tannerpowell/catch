import { test, expect } from "@playwright/test";
import { e2eUrls } from "./_helpers";

test.describe("Order confirmation page", () => {
  test("loads and shows order details (smoke)", async ({ page }) => {
    const { orderPrefix } = e2eUrls();

    // If your app uses a different route, override E2E_ORDER_CONFIRMATION_URL_PREFIX.
    // Without a real order id, this is intentionally a template.
    // Recommended approach: after checkout, capture the resulting URL and assert order details there.
    test.skip(true, `Template spec: wire this after checkout to assert the confirmation page. Expected prefix: ${orderPrefix}`);
  });
});
