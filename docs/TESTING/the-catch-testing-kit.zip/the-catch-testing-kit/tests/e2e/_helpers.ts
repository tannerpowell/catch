import { expect, Page, test } from "@playwright/test";

export function requireTestIds(): boolean {
  return process.env.E2E_REQUIRE_TESTIDS === "1";
}

export async function ensureTestId(page: Page, testId: string, message: string) {
  const locator = page.getByTestId(testId);
  const count = await locator.count();
  if (count === 0) {
    if (requireTestIds()) {
      throw new Error(message);
    }
    test.skip(true, message);
  }
  return locator.first();
}

export async function gotoOrSkip(page: Page, url: string) {
  // Basic guard to skip if route doesn't exist (e.g., returns 404).
  const resp = await page.goto(url, { waitUntil: "domcontentloaded" });
  if (!resp) return;
  if (resp.status() === 404) {
    if (requireTestIds()) {
      throw new Error(`Route returned 404: ${url}`);
    }
    test.skip(true, `Route returned 404 (update env var or route): ${url}`);
  }
}

export function e2eUrls() {
  return {
    menu: process.env.E2E_MENU_URL ?? "/menu",
    cart: process.env.E2E_CART_URL ?? "/cart",
    checkout: process.env.E2E_CHECKOUT_URL ?? "/checkout",
    orderPrefix: process.env.E2E_ORDER_CONFIRMATION_URL_PREFIX ?? "/order",
    kitchen: process.env.E2E_KITCHEN_URL ?? "/kitchen",
  };
}

export async function expectAnyCartCount(page: Page) {
  const badge = page.getByTestId("cart-badge-count");
  await expect(badge).toBeVisible();
  const txt = (await badge.textContent())?.trim() ?? "";
  const n = Number.parseInt(txt, 10);
  expect(Number.isFinite(n)).toBeTruthy();
  expect(n).toBeGreaterThan(0);
}
