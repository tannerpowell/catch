import { describe, test } from "vitest";

/**
 * Helper to avoid hard-failing when this kit is copied into a repo
 * that uses different import paths or names.
 *
 * Usage:
 *   const mod = await importOrSkip(() => import("@/lib/money"));
 */
export async function importOrSkip<T>(importer: () => Promise<T>, reason: string): Promise<T | null> {
  try {
    return await importer();
  } catch (err) {
    describe(reason, () => {
      test.skip(true, String(err));
    });
    return null;
  }
}
