import { defineConfig, devices } from "@playwright/test";

/**
 * Playwright runs against a built Next.js app by default for fidelity.
 * If you prefer dev mode, change the webServer command to "npx next dev -p 3000".
 */
export default defineConfig({
  testDir: "./tests/e2e",
  timeout: 60_000,
  expect: { timeout: 10_000 },
  retries: process.env.CI ? 2 : 0,
  reporter: process.env.CI ? [["github"], ["html", { open: "never" }]] : [["list"], ["html"]],
  use: {
    baseURL: process.env.PLAYWRIGHT_BASE_URL ?? "http://127.0.0.1:3000",
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
    video: "retain-on-failure",
  },
  webServer: {
    command: process.env.PLAYWRIGHT_WEBSERVER_COMMAND
      ?? "npm run build && npx next start -p 3000",
    url: "http://127.0.0.1:3000",
    reuseExistingServer: !process.env.CI,
    timeout: 120_000,
  },
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
    // Add WebKit later if you want iPad/Safari parity:
    // { name: "webkit", use: { ...devices["Desktop Safari"] } },
  ],
});
