# The Catch — Testing Infrastructure Starter Kit (Playwright + Vitest)

Date: 2026-01-03

This zip is a **drop-in scaffold** for adding:
- Playwright (E2E)
- Vitest (unit)
- GitHub Actions CI

Because I do not have your repository files here, the tests are written to be:
- **Deterministic-friendly** (fixture hooks included)
- **Non-breaking by default**: E2E tests will **skip** with clear instructions if required `data-testid` selectors are not present yet.
- **Easy to wire up** once you add a small set of `data-testid` attributes.

---

## 1) Install dev dependencies

Pick one package manager; examples below use npm.

```bash
npm i -D \
  @playwright/test \
  vitest \
  jsdom \
  @vitest/coverage-v8 \
  @testing-library/react \
  @testing-library/jest-dom \
  @testing-library/user-event \
  @vitejs/plugin-react \
  vite-tsconfig-paths
```

Then install Playwright browsers:

```bash
npx playwright install --with-deps
```

---

## 2) Add scripts to `package.json`

Add (or merge) these:

```json
{
  "scripts": {
    "test": "npm run test:unit && npm run test:e2e",
    "test:unit": "vitest run",
    "test:unit:watch": "vitest",
    "test:e2e": "playwright test",
    "test:e2e:ui": "playwright test --ui",
    "test:e2e:debug": "PWDEBUG=1 playwright test"
  }
}
```

---

## 3) Copy files into your repo root

Copy these files/folders into the root of your Next.js repo:

- `playwright.config.ts`
- `vitest.config.ts`
- `vitest.setup.ts`
- `tests/`
- `.github/workflows/tests.yml`

---

## 4) Add a small set of `data-testid` selectors (high ROI)

Your Playwright tests prefer stable selectors like:

### Menu
- `data-testid="category-nav"`
- `data-testid="menu-item-<id or slug>"`
- `data-testid="item-modal"`
- `data-testid="add-to-cart"`

### Cart
- `data-testid="cart-badge-count"`
- `data-testid="cart-row-<id>"`
- `data-testid="qty-increase-<id>"`
- `data-testid="qty-decrease-<id>"`
- `data-testid="remove-item-<id>"`
- `data-testid="cart-total"`

### Checkout
- `data-testid="checkout-form"`
- `data-testid="checkout-submit"`
- (Optional) `data-testid="field-error-<fieldName>"`

### Kitchen (KDS)
- `data-testid="kds-board"`
- `data-testid="kds-column-new"`, `kds-column-prep`, `kds-column-ready` (whatever your statuses are)
- `data-testid="kds-order-<id>"`
- `data-testid="kds-advance-status-<id>"`

Until these exist, E2E specs will skip with an actionable message.

---

## 5) Configure base URLs / routes (if your paths differ)

Defaults used:
- Menu URL: `/menu`
- Cart URL: `/cart`
- Checkout URL: `/checkout`
- Kitchen URL: `/kitchen`

Override with env vars:

```bash
E2E_MENU_URL=/menu2 E2E_KITCHEN_URL=/kitchen npm run test:e2e
```

See: `tests/e2e/env.example`

---

## 6) Fixture mode (optional but recommended)

This kit includes **hooks** to support deterministic fixtures:
- E2E tests can run against your real Sanity dev dataset, OR
- You can implement `USE_FIXTURES=1` in your Sanity data layer and/or order polling endpoint.

Suggested approach:
- Add `USE_FIXTURES=1` branch in your Sanity fetch wrapper to load JSON from `tests/fixtures/sanity/*.json`.
- Add `USE_FIXTURES=1` branch for kitchen orders to load from `tests/fixtures/orders/sample-orders.json`.

The kit already includes sample fixture files:
- `tests/fixtures/sanity/menu.sample.json`
- `tests/fixtures/orders/sample-orders.json`

---

## 7) CI

GitHub Actions workflow is included at `.github/workflows/tests.yml`.

It runs:
- unit tests (Vitest)
- build (Next)
- E2E tests (Playwright)

---

## What you should do next (minimal path to green)

1. Copy this kit into your repo root.
2. Install deps + Playwright browsers.
3. Add 10–15 `data-testid`s.
4. Run:
   - `npm run test:unit`
   - `npm run test:e2e`

If E2E skips, follow the skip message and add the missing selector(s).

